package com.navinda.document;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DocumentWebApplication {

	public static void main(String[] args) {
		SpringApplication.run(DocumentWebApplication.class, args);
	}

}
